package com.example.minp;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, TextToSpeech.OnInitListener {

    Button calcB;
    EditText principle, downPayment, tenure, interest;
    TextView res;

    TextToSpeech tts;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calcB = findViewById(R.id.bCalc);
        calcB.setOnClickListener(this);
        principle = findViewById(R.id.ePA);
        downPayment = findViewById(R.id.eDP);
        interest = findViewById(R.id.eIR);
        tenure = findViewById(R.id.eLT);
        res = findViewById(R.id.tR);
        tts = new TextToSpeech(getApplicationContext(), this);
    }

    @Override
    public void onClick(View v) {
        if(v.equals(calcB)){
            try {
                double emi;
                long p = Long.parseLong(principle.getText().toString());
                long d = Long.parseLong(downPayment.getText().toString());
                float r = Float.parseFloat(interest.getText().toString());
                int t = Integer.parseInt(tenure.getText().toString());

                p = p - d;
                r = r / 1200;
                emi = p * (r * Math.pow((1 + r), t)) / (Math.pow((1 + r), t) - 1);
                emi = Math.floor(emi * 100) / 100;
                if(emi<0){
                    Toast.makeText(getBaseContext(),"Invalid Input", Toast.LENGTH_LONG).show();
                }
                else {
                    res.setText(String.valueOf(emi));

                    String speak = "";
                    speak = speak + "The amount to be paid per month is " + res.getText().toString() + "Indian Rupees";
                    tts.speak(speak, TextToSpeech.QUEUE_FLUSH, null);
                }
            }
            catch (Exception e){
                Toast.makeText(getBaseContext(),"Invalid Input", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onInit(int i) {
        if(i != TextToSpeech.ERROR){
            tts.setLanguage(Locale.ENGLISH);
        }
    }
}